document.addEventListener('DOMContentLoaded', () => {
    const mobileMenu = document.querySelector('.mobile-menu');
    const menuBtnOpen = document.querySelector('.menu-btn-open');
    const menuBtnClose = document.querySelector('.menu-btn-close');
    
    // Проверяем, что элементы найдены
    console.log("Elements found:", mobileMenu, menuBtnOpen, menuBtnClose);

    // Функция для открытия и закрытия меню
    const toggleMenu = () => {
        console.log("Toggle menu function called");  // Сообщение при вызове функции
        mobileMenu.classList.toggle('is-open');
    };

    // Добавление обработчиков событий с дополнительной отладкой
    if (menuBtnOpen) {
        menuBtnOpen.addEventListener('click', () => {
            console.log("Open menu button clicked");
            toggleMenu();
        });
    } else {
        console.error("menuBtnOpen element not found");
    }

    if (menuBtnClose) {
        menuBtnClose.addEventListener('click', () => {
            console.log("Close menu button clicked");
            toggleMenu();
        });
    } else {
        console.error("menuBtnClose element not found");
    }

    // Закрытие поп-апа после клика по ссылке
    const menuLinks = document.querySelectorAll('.mobile-menu a');
    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            toggleMenu();  // Закрываем меню при клике по ссылке
        });
    });
});
