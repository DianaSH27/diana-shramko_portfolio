const swiper = new Swiper('.swiper-conteiner', {
  loop: true,
  slidesPerView: 1,
  spaceBetween: 20,
  breakpoints: {

    600: {
      slidesPerView: 2,

    },

    900: {
      slidesPerView: 3,

    }
  },

  pagination: {
    el: '.pagination',
    bulletClass: 'pagination-button',
    bulletActiveClass: 'pagination-button--active',
    clickable: true,

  },

  navigation: {
    nextEl: '.carousel-button.next',
    prevEl: '.carousel-button.prev',
  },
});