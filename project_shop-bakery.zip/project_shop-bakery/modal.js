
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.querySelector('.backdrop');
    const modalBtnOpenAll = document.querySelectorAll('.modal-btn-open'); 
    const modalBtnClose = document.querySelector('.modal-btn-close');


    modal.classList.add('is-hidden');

    const toggleModal = () => {
        modal.classList.toggle('is-hidden');

        if (modal.classList.contains('is-hidden')) {
            localStorage.setItem('modalClosed', 'true');
        } else {
            localStorage.removeItem('modalClosed');
        }
    };

    if (localStorage.getItem('modalClosed')) {
        modal.classList.add('is-hidden');
    } else {
        modal.classList.remove('is-hidden');
    }

    modalBtnOpenAll.forEach(button => {
        button.addEventListener('click', toggleModal);
    });

    if (modalBtnClose) {
        modalBtnClose.addEventListener('click', toggleModal);
    }
});


jQuery(document).ready(function($) {

        $('.flexslider').flexslider({
            animation: "slide",
            animationLoop: false,
            itemWidth: 349,
            itemMargin: 20,
            minItems: 1,
            maxItems: 6
        });

});
